package com.example.project;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

public class ShareFragment extends Fragment {

    EditText emailInput;
    EditText userMessageInput;
    TextView TaskBody;
    Button sendButton;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_share, container, false);

        String SwipedTitle = getArguments().getString("task_title");
        DatabaseHelper dataBaseHelper = new DatabaseHelper(requireContext(), "TaskManagementAPP", null, 1);
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("UserPrefs", requireContext().MODE_PRIVATE);
        String useremail = sharedPreferences.getString("email", "");
        TASK task = dataBaseHelper.getTASK(SwipedTitle, useremail);

        emailInput = view.findViewById(R.id.email_input);
        sendButton = view.findViewById(R.id.send_button);
        TaskBody = view.findViewById(R.id.Taskbody);
        userMessageInput = view.findViewById(R.id.userMessageInput);

        // Display the task information in the TextView
        String taskDetails = task.toString();
        TaskBody.setText(taskDetails);

        // Set up the Send button click listener
        sendButton.setOnClickListener(v -> {
            String email = emailInput.getText().toString();
            String userMessage = userMessageInput.getText().toString(); // Get the user's message input

            if (!email.isEmpty()) {
                if (isValidEmail(email)) {
                    // Concatenate task details and the user's message
                    String fullMessage = taskDetails + "\n\n" + "User's Message: \n" + userMessage;
                    sendEmail(email, fullMessage); // Pass the full concatenated message
                } else {
                    Toast.makeText(getContext(), "Please enter a valid email address", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), "Please enter an email address", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }


    private void sendEmail(String email, String fullMessage) {
        // Create an email intent
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("message/rfc822"); // Use message/rfc822 for email

        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{email}); // Set the recipient
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Task Details"); // Set the subject
        emailIntent.putExtra(Intent.EXTRA_TEXT, fullMessage); // Set the message content to task details and user's message

        // Check if an email client is available to handle the intent
        if (emailIntent.resolveActivity(getActivity().getPackageManager()) != null) {
            startActivity(Intent.createChooser(emailIntent, "Send Email"));
        } else {
            // Show a message if no email client is available
            Toast.makeText(getContext(), "No email client installed", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isValidEmail(String email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }
}
