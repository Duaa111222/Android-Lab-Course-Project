package com.example.project;

import android.content.ContentValues;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import androidx.fragment.app.Fragment;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AccountFragment extends Fragment {

    private Button updateButton;
    private EditText emailEditText, passwordEditText, firstNameEditText, lastNameEditText;
    String useremail;
    SharedPreferences sharedPreferences;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_account, container, false);
        DatabaseHelper dataBaseHelper = new DatabaseHelper(requireContext(), "TaskManagementAPP", null, 1);


        SharedPreferences sharedPreferences;
        sharedPreferences = requireContext().getSharedPreferences("UserPrefs", requireContext().MODE_PRIVATE);
        useremail= sharedPreferences.getString("email", "");



        updateButton = view.findViewById(R.id.updateButton);
        emailEditText = view.findViewById(R.id.emailEditText);
        passwordEditText = view.findViewById(R.id.passwordEditText);
        firstNameEditText = view.findViewById(R.id.firstNameEditText);
        lastNameEditText = view.findViewById(R.id.lastNameEditText);
        firstNameEditText.setKeyListener(null);
        lastNameEditText.setKeyListener(null);
        firstNameEditText.setTextColor(getResources().getColor(R.color.lavender));
        lastNameEditText.setTextColor(getResources().getColor(R.color.lavender));


        emailEditText.setText(useremail);
        USER user = new USER();
        user = dataBaseHelper.getuserbyemail(useremail);
        if(user != null){
            passwordEditText.setText(user.getPassword());
            firstNameEditText.setText(user.getFIRSTName());
            lastNameEditText.setText(user.getLASTName());
        }

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //update user info
                USER user = new USER();
                user.setEmail(emailEditText.getText().toString());
                boolean isvalid = validate(emailEditText.getText().toString(), passwordEditText.getText().toString());
                user.setPassword(passwordEditText.getText().toString());
                user.setFIRSTName(firstNameEditText.getText().toString());
                user.setLASTName(lastNameEditText.getText().toString());
                if (isvalid) {
                    boolean isUpdated = dataBaseHelper.updateUSER(user, useremail);
                    if (isUpdated) {
                        SharedPreferences sharedPreferences;
                        sharedPreferences = requireContext().getSharedPreferences("UserPrefs", requireContext().MODE_PRIVATE);
                        sharedPreferences.edit()
                                .putString("email", emailEditText.getText().toString())
                                .putString("password", passwordEditText.getText().toString())
                                .apply();
                        update_useremail_intasks(useremail, emailEditText.getText().toString());
                        Toast.makeText(requireContext(), "User info updated successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(requireContext(), "Email is not unique", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        return view;
    }
    public boolean validate(String email, String password) {
        if (!password.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{6,12}$")) {
            passwordEditText.setError("Password must be 6-12 characters with a number, a lowercase, and an uppercase letter");
            return false;
        }
        if (TextUtils.isEmpty(email) || !email.contains("@")) {
            emailEditText.setError("Enter valid email");
            return false;
        }
        return true;
    }

    public void update_useremail_intasks(String oldemail, String newemail) {

        DatabaseHelper dataBaseHelper = new DatabaseHelper(requireContext(), "TaskManagementAPP", null, 1);
        SQLiteDatabase db = dataBaseHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("USEREmail", newemail);
        db.update("TASKS", values, "USEREmail = ?", new String[]{oldemail});
        db.close();

    }

}