package com.example.project;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.core.app.NotificationManagerCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


public class ReminderFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_reminder, container, false);
        // Inflate the layout for this fragment
        DatabaseHelper dataBaseHelper = new DatabaseHelper(requireContext(), "TaskManagementAPP", null, 1);
        SharedPreferences sharedPreferences;
        sharedPreferences = requireContext().getSharedPreferences("UserPrefs", requireContext().MODE_PRIVATE);
        String useremail= sharedPreferences.getString("email", "");


        FloatingActionButton addReminder = view.findViewById(R.id.addReminder);
        FloatingActionButton deleteReminder = view.findViewById(R.id.deleteReminder);
        final EditText dueDate = view.findViewById(R.id.due_date);
        final EditText dueTime = view.findViewById(R.id.due_time);
        final EditText title = view.findViewById(R.id.tasktitle);

        // Setup Date Picker for Due Date
        dueDate.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            // Show Date Picker Dialog
            new android.app.DatePickerDialog(requireContext(), (view1, year1, month1, dayOfMonth) -> {
                String dayofmont = String.valueOf(dayOfMonth);
                if (dayOfMonth < 10) {
                    dayofmont = "0" + dayofmont;
                }
                String monthstring = String.valueOf(month1 + 1 );
                if (month1 < 10) {
                    monthstring = "0" + month1;
                }

                // Format the selected date
                String selectedDate = year1 + "-" + (monthstring) + "-" + dayofmont;
                dueDate.setText(selectedDate);
            }, year, month, day).show();
        });

        // Setup Time Picker for Due Time
        dueTime.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);

            // Show Time Picker Dialog
            new android.app.TimePickerDialog(requireContext(), (view12, hourOfDay, minute1) -> {
                // Format the selected time
                String selectedTime = String.format("%02d:%02d", hourOfDay, minute1);
                dueTime.setText(selectedTime);
            }, hour, minute, true).show();
        });

        addReminder.setOnClickListener(v -> {

            //search the task title in the database
            TASK task = dataBaseHelper.getTASK(title.getText().toString(),useremail);
            if (task != null) {
                if (dueDate.getText().toString().isEmpty() || dueTime.getText().toString().isEmpty() ) {
                    Toast.makeText(requireContext(), "Please enter a Reminder date and time", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (validateDueDateAndTime(dueDate.getText().toString(),dueTime.getText().toString()) == false) {
                    Toast.makeText(requireContext(), "Please enter a valid due date and time", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!task.getSTATUS().equals("incomplete")) {
                    Toast.makeText(requireContext(), "This Task is Already Completed ", Toast.LENGTH_SHORT).show();
                    return;
                }

                long triggerTime = getTriggerTime(dueDate.getText().toString(), dueTime.getText().toString());
               // int requestCode = (title.getText());
                int requestCode = dataBaseHelper.getTaskIdByTitle(task.getTITLE(),useremail);
                //remove previous reminder
                cancelReminder(requireContext(), requestCode);
                scheduleNotification(triggerTime, title.getText().toString(), requestCode);

                // Display confirmation to the user
                Date triggerDate = new Date(triggerTime);
                Toast.makeText(requireContext(), "A reminder is scheduled at: " + triggerDate, Toast.LENGTH_SHORT).show();


            } else {
                Toast.makeText(requireContext(), "Task Not Found", Toast.LENGTH_SHORT).show();
                return;
            }

        });

        deleteReminder.setOnClickListener(v -> {
            //search the task title in the database
            TASK task = dataBaseHelper.getTASK(title.getText().toString(),useremail);
            if (task != null) {
                // int requestCode = (title.getText());
                int requestCode = dataBaseHelper.getTaskIdByTitle(task.getTITLE(),useremail);
                //remove previous reminder
                cancelReminder(requireContext(), requestCode);
                // Display confirmation to the user
                Toast.makeText(requireContext(), "The reminder is canceled " ,Toast.LENGTH_SHORT).show();

            } else {
                Toast.makeText(requireContext(), "Task Not Found", Toast.LENGTH_SHORT).show();
            }
        });
        return view;
    }


    private boolean validateDueDateAndTime(String dueDate, String dueTime) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
        try {
            Date date = dateFormat.parse(dueDate + " " + dueTime);
            if (date != null && date.before(new Date())) {
                return false; // The due date and time is before the current date and time
            }
        } catch (ParseException e) {
            e.printStackTrace();
            return false; // Invalid date format
        }
        return true; // The due date and time is valid and not before the current date and time
    }

    private long getTriggerTime(String dueDate, String dueTime) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
        try {
            Date date = dateFormat.parse(dueDate + " " + dueTime);
            if (date != null) {
                return date.getTime() ; // Return the time in milliseconds
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return System.currentTimeMillis(); // Default to current time if parsing fails
    }

    private void scheduleNotification(long triggerTime, String taskTitle, int requestCode) {
        Context context = requireContext();
        Intent intent = new Intent(context, ReminderBroadcastReceiver.class);
        intent.putExtra("taskTitle", taskTitle);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, requestCode,intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent);
        }

    }
    public static void cancelReminder(Context context, int requestCode) {
        Intent intent = new Intent(context, ReminderBroadcastReceiver.class);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null) {
            alarmManager.cancel(pendingIntent);
        }

        // Cancel the notification as well
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);
        notificationManager.cancel(requestCode);
    }

}