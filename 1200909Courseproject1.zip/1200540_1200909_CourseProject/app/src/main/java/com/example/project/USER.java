package com.example.project;


public class USER {
    private String FIRSTName;
    private String LASTName;
    private String Email;
    private String Password;


    public USER() {
    }

    public USER(String FIRSTName, String LASTName, String Email, String Password) {
        this.FIRSTName = FIRSTName;
        this.LASTName = LASTName;
        this.Email = Email;
        this.Password = Password;

    }

    public String getFIRSTName() {
        return FIRSTName;
    }
    public void setFIRSTName(String FIRSTName) {
        this.FIRSTName = FIRSTName;
    }

    public String getLASTName() {
        return LASTName;
    }
    public void setLASTName(String LASTName) {
        this.LASTName = LASTName;
    }

    public String getEmail() {
        return Email;
    }
    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getPassword() {
        return Password;
    }
    public void setPassword(String Password) {
        this.Password = Password;
    }
    @Override
    public String toString() {
        return "USER{" +
                "\n, FIRSTName='" + FIRSTName + '\'' +
                "\n, LASTName='" + LASTName + '\'' +
                "\n, Email='" + Email + '\'' +
                "\n, Password='" + Password + '\'' +
                "\n}\n\n";
    }

}