package com.example.project;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {

    private final List<TASK> taskList;
    private final OnTaskCheckChangeListener listener;
    private final DatabaseHelper myDB;
    private final OnTaskClickListener taskClickListener;
    private final Context context;

    // Interface to handle task click
    public interface OnTaskClickListener {
        void onTaskClick(TASK task);
    }

    // Interface to handle task check/uncheck
    public interface OnTaskCheckChangeListener {
        void onTaskChecked(boolean isChecked);
        void onAllTasksChecked();
    }

    public TaskAdapter(Context context,List<TASK> taskList, OnTaskCheckChangeListener listener, DatabaseHelper myDB, OnTaskClickListener taskClickListener) {
        this.taskList = taskList;
        this.listener = listener;
        this.myDB = myDB;
        this.taskClickListener = taskClickListener;
        this.context = context;
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.task_layout, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        TASK task = taskList.get(position);
        holder.taskCheckBox.setText(task.getTITLE());
        holder.taskCheckBox.setChecked("complete".equalsIgnoreCase(task.getSTATUS()));

        // Set listener for task item click
        holder.itemView.setOnClickListener(v -> {
            if (taskClickListener != null) {
                taskClickListener.onTaskClick(task);
            }
        });

        holder.taskCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            String newStatus = isChecked ? "Complete" : "incomplete";
            task.setSTATUS(newStatus); // Update the task object
            SharedPreferences sharedPreferences = context.getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
            String email = sharedPreferences.getString("email", "");
            // Update the database
            myDB.updateTaskStatus(task.getTITLE(),email,newStatus);

            if (listener != null) {
                listener.onTaskChecked(isChecked);
                if (areAllTasksChecked()) {
                    listener.onAllTasksChecked();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return taskList.size();
    }

    private boolean areAllTasksChecked() {
        for (TASK task : taskList) {
            if (!"complete".equalsIgnoreCase(task.getSTATUS())) {
                return false;
            }
        }
        return true;
    }

    public TASK getTaskAt(int position) {
        return taskList.get(position);
    }

    public void removeTask(int position) {
        taskList.remove(position);
        notifyItemRemoved(position);
    }

    public static class TaskViewHolder extends RecyclerView.ViewHolder {
        CheckBox taskCheckBox;

        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            taskCheckBox = itemView.findViewById(R.id.checkbox);
        }
    }
}
