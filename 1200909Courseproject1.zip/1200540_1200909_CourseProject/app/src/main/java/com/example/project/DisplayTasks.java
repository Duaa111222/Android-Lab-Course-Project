package com.example.project;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class DisplayTasks extends Fragment implements TaskAdapter.OnTaskClickListener, TaskAdapter.OnTaskCheckChangeListener {

    RecyclerView recyclerView;
    Spinner taskOptionsSpinner;
    FloatingActionButton executeButton;

    TaskAdapter taskAdapter;
    DatabaseHelper myDB;
    String useremail;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_display_tasks, container, false);

        recyclerView = view.findViewById(R.id.recyclerview);
        taskOptionsSpinner = view.findViewById(R.id.task_options_spinner);
        executeButton = view.findViewById(R.id.execute_button);

        myDB = new DatabaseHelper(requireContext(), "TaskManagementAPP", null, 1);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));

        setUpSpinner();
        setUpExecuteButton();
        setUpItemTouchHelper();

        return view;
    }

    private void setUpSpinner() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(requireContext(),
                R.array.task_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        taskOptionsSpinner.setAdapter(adapter);
    }

    private void setUpExecuteButton() {
        executeButton.setOnClickListener(v -> {
            int selectedOption = taskOptionsSpinner.getSelectedItemPosition();

            switch (selectedOption) {
                case 0: // All Tasks
                    Toast.makeText(getContext(), "Loading all tasks...", Toast.LENGTH_SHORT).show();
                    allTasks();
                    break;

                case 1: // Completed Tasks
                    Toast.makeText(getContext(), "Loading completed tasks...", Toast.LENGTH_SHORT).show();
                    allcompletedTasks();
                    break;

                case 2: // Tasks in Specific Date Range
                    Toast.makeText(getContext(), "Please specify date range.", Toast.LENGTH_SHORT).show();
                    showDateRangeDialog();
                    break;

                default:
                    break;
            }
        });
    }

    private void allTasks() {
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("UserPrefs", requireContext().MODE_PRIVATE);
        useremail = sharedPreferences.getString("email", "");

        Cursor cursor = myDB.selectAllTasks_grouped_by_day(useremail);
        List<TASK> tasks = new ArrayList<>();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") TASK task = new TASK(cursor.getString(cursor.getColumnIndex("userEMAIL")),

                        cursor.getString(cursor.getColumnIndex("TITLE")),
                        cursor.getString(cursor.getColumnIndex("DESCRIPTION")),
                        cursor.getString(cursor.getColumnIndex("PRIORITY")),
                        cursor.getString(cursor.getColumnIndex("STATUS")),
                        cursor.getString(cursor.getColumnIndex("REMINDER")),
                        cursor.getString(cursor.getColumnIndex("DUEDATE")),
                        cursor.getString(cursor.getColumnIndex("DUETIME")));
                tasks.add(task);
            } while (cursor.moveToNext());
        }

        if (cursor != null) {
            cursor.close();
        }

        taskAdapter = new TaskAdapter(requireContext(), tasks, this, myDB, this);
        recyclerView.setAdapter(taskAdapter);
    }

    private void allcompletedTasks() {
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("UserPrefs", requireContext().MODE_PRIVATE);
        useremail = sharedPreferences.getString("email", "");

        Cursor cursor = myDB.selectCompletedTasks_grouped_by_day(useremail);
        List<TASK> tasks = new ArrayList<>();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") TASK task = new TASK(cursor.getString(cursor.getColumnIndex("userEMAIL")),

                        cursor.getString(cursor.getColumnIndex("TITLE")),
                        cursor.getString(cursor.getColumnIndex("DESCRIPTION")),
                        cursor.getString(cursor.getColumnIndex("PRIORITY")),
                        cursor.getString(cursor.getColumnIndex("STATUS")),
                        cursor.getString(cursor.getColumnIndex("REMINDER")),
                        cursor.getString(cursor.getColumnIndex("DUEDATE")),
                        cursor.getString(cursor.getColumnIndex("DUETIME")));
                tasks.add(task);
            } while (cursor.moveToNext());
        }

        if (cursor != null) {
            cursor.close();
        }

        taskAdapter = new TaskAdapter(requireContext(), tasks, this, myDB, this);
        recyclerView.setAdapter(taskAdapter);
    }

    private void showDateRangeDialog() {
        // Get current date for DatePicker
        final Calendar calendar = Calendar.getInstance();
        int currentYear = calendar.get(Calendar.YEAR);
        int currentMonth = calendar.get(Calendar.MONTH);
        int currentDay = calendar.get(Calendar.DAY_OF_MONTH);

        // Show date range picker dialog
        DatePickerDialog startDatePicker = new DatePickerDialog(requireContext(),
                (view, year, month, dayOfMonth) -> {
                    String startDate = year + "-" + (month + 1) + "-" + dayOfMonth;
                    DatePickerDialog endDatePicker = new DatePickerDialog(requireContext(),
                            (view1, year1, month1, dayOfMonth1) -> {
                                String endDate = year1 + "-" + (month1 + 1) + "-" + dayOfMonth1;
                                Toast.makeText(getContext(), "Loading tasks from " + startDate + " to " + endDate, Toast.LENGTH_SHORT).show();
                                loadTasksByDateRange(startDate, endDate);
                            }, currentYear, currentMonth, currentDay);
                    endDatePicker.show();
                }, currentYear, currentMonth, currentDay);
        startDatePicker.show();
    }

    private void loadTasksByDateRange(String startDate, String endDate) {
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("UserPrefs", requireContext().MODE_PRIVATE);
        useremail = sharedPreferences.getString("email", "");

        Cursor cursor = myDB.Tasksinspecificdate_grouped_by_day(useremail, startDate, endDate);
        List<TASK> tasks = new ArrayList<>();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") TASK task = new TASK(cursor.getString(cursor.getColumnIndex("userEMAIL")),

                        cursor.getString(cursor.getColumnIndex("TITLE")),
                        cursor.getString(cursor.getColumnIndex("DESCRIPTION")),
                        cursor.getString(cursor.getColumnIndex("PRIORITY")),
                        cursor.getString(cursor.getColumnIndex("STATUS")),
                        cursor.getString(cursor.getColumnIndex("REMINDER")),
                        cursor.getString(cursor.getColumnIndex("DUEDATE")),
                        cursor.getString(cursor.getColumnIndex("DUETIME")));
                tasks.add(task);
            } while (cursor.moveToNext());
        }

        if (cursor != null) {
            cursor.close();
        }

        taskAdapter = new TaskAdapter(requireContext(), tasks, this, myDB, this);
        recyclerView.setAdapter(taskAdapter);
    }

    @Override
    public void onTaskClick(TASK task) {
        // Create a Bundle and add the task title
        Bundle bundle = new Bundle();
        bundle.putString("task_title", task.getTITLE());  // Replace with your task object field
        ManageTasksFragment manageTasksFragment = new ManageTasksFragment();
        manageTasksFragment.setArguments(bundle);  // Pass the bundle to the fragment
        requireFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, manageTasksFragment)
                .addToBackStack(null)  // Optionally add to back stack
                .commit();

    }

    @Override
    public void onTaskChecked(boolean isChecked) {
        // Handle checkbox toggling
        Toast.makeText(getContext(), isChecked ? "Task checked!" : "Task unchecked!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onAllTasksChecked() {
        // Show congratulations animation/dialog
        showCongratulationsDialog();
    }

    private void showCongratulationsDialog() {
        View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.congratulations_dialog, null);

        // Initialize animation
        Animation animation = AnimationUtils.loadAnimation(requireContext(), R.anim.congratulations_animation);
        ImageView imageView = dialogView.findViewById(R.id.congratulationsImage);
        imageView.startAnimation(animation);

        // Create and show dialog
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(requireContext());
        builder.setView(dialogView)
                .setCancelable(false)
                .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
              .show();}


    private void setUpItemTouchHelper() {
        ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false; // No need to handle item movement
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                TASK swipedTask = taskAdapter.getTaskAt(position); // Get the task at this position

                if (direction == ItemTouchHelper.LEFT) {
                    // Swipe left - display a toast (or perform any other action like marking as complete)
                    Toast.makeText(requireContext(), "Share Task via Email: " + swipedTask.getTITLE(), Toast.LENGTH_SHORT).show();
                    taskAdapter.notifyItemChanged(position);
                    Bundle bundle = new Bundle();
                    bundle.putString("task_title", swipedTask.getTITLE()); // Add the task title to the bundle
                    ShareFragment ShareFragment = new ShareFragment();
                    ShareFragment.setArguments(bundle);  // Pass the bundle to the fragment
                    requireFragmentManager().beginTransaction()
                            .replace(R.id.fragment_container, ShareFragment)
                            .addToBackStack(null)  //  add to back stack
                            .commit();


                } else if (direction == ItemTouchHelper.RIGHT) {
                    // Swipe right - delete the task
                    Toast.makeText(requireContext(), "Task deleted: " + swipedTask.getTITLE(), Toast.LENGTH_SHORT).show();
                    myDB.deleteTASKbyUSER(swipedTask.getTITLE(), useremail);  // Assuming you have a method for deleting tasks by title

                    // Remove the task from the list and update the adapter
                    taskAdapter.removeTask(position);
                }
            }
        };

        // Attach the ItemTouchHelper to the RecyclerView
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);
    }

}
