package com.example.project;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class ManageTasksFragment extends Fragment {

    String useremail;
    SharedPreferences sharedPreferences;
    private String SwipedTitle = null;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_manage_tasks, container, false);
        DatabaseHelper dataBaseHelper = new DatabaseHelper(requireContext(), "TaskManagementAPP", null, 1);
        if (getArguments() != null) {
            SwipedTitle = getArguments().getString("task_title");
        }


        // Define the options for the priority spinner
        String[] options = {"Medium", "Low", "High"};
        final Spinner prioritySpinner = view.findViewById(R.id.priority_level_spinner);
        ArrayAdapter<String> priorityAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, options);
        priorityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        prioritySpinner.setAdapter(priorityAdapter);

        // Define the options for the status spinner
        String[] statusoptions = {"incomplete", "Complete"};
        final Spinner statusSpinner = view.findViewById(R.id.completion_status_spinner);
        ArrayAdapter<String> statusAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, statusoptions);
        statusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        statusSpinner.setAdapter(statusAdapter);

        EditText title = view.findViewById(R.id.task_title);
        EditText description = view.findViewById(R.id.task_description);
        final EditText dueDate = view.findViewById(R.id.due_date);
        final EditText dueTime = view.findViewById(R.id.due_time);
        CheckBox reminderCheckBox = view.findViewById(R.id.reminderCheckBox);

        SharedPreferences sharedPreferences;
        sharedPreferences = requireContext().getSharedPreferences("UserPrefs", requireContext().MODE_PRIVATE);
        useremail= sharedPreferences.getString("email", "");

        if (SwipedTitle != null) {
            title.setText(SwipedTitle);
            TASK task = dataBaseHelper.getTASK(title.getText().toString(),useremail);
            if (task != null) {
                title.setText(task.getTITLE());
                description.setText(task.getDESCRIPTION());
                prioritySpinner.setSelection(priorityAdapter.getPosition(task.getPRIORITY()));
                statusSpinner.setSelection(statusAdapter.getPosition(task.getSTATUS()));
                reminderCheckBox.setChecked(task.getREMINDER().equals("yes"));
                dueDate.setText(task.getDUEDATE());
                dueTime.setText(task.getDUETIME());
            }


        }
        // Setup Date Picker for Due Date
        dueDate.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            // Show Date Picker Dialog
            new android.app.DatePickerDialog(requireContext(), (view1, year1, month1, dayOfMonth) -> {
                String dayofmont = String.valueOf(dayOfMonth);
                if (dayOfMonth < 10) {
                    dayofmont = "0" + dayofmont;
                }
                String monthstring = String.valueOf(month1 + 1 );
                if (month1 < 10) {
                    monthstring = "0" + month1;
                }

                // Format the selected date
                String selectedDate = year1 + "-" + (monthstring) + "-" + dayofmont;
                dueDate.setText(selectedDate);
            }, year, month, day).show();
        });

        // Setup Time Picker for Due Time
        dueTime.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);

            // Show Time Picker Dialog
            new android.app.TimePickerDialog(requireContext(), (view12, hourOfDay, minute1) -> {
                // Format the selected time
                String selectedTime = String.format("%02d:%02d", hourOfDay, minute1);
                dueTime.setText(selectedTime);
            }, hour, minute, true).show();
        });

        // Add new task button functionality
        Button addtaskButton = view.findViewById(R.id.save_task_button);
        addtaskButton.setOnClickListener(v -> {
            TASK task = new TASK();
            task.setUSEREmail(useremail);
            task.setTITLE(title.getText().toString());
            task.setDESCRIPTION(description.getText().toString());
            task.setPRIORITY(prioritySpinner.getSelectedItem().toString());
            task.setSTATUS(statusSpinner.getSelectedItem().toString());
            task.setREMINDER(reminderCheckBox.isChecked() ? "yes" : "no");
            task.setDUEDATE(dueDate.getText().toString());
            task.setDUETIME(dueTime.getText().toString());

            if (dueDate.getText().toString().isEmpty() || dueTime.getText().toString().isEmpty() && reminderCheckBox.isChecked()) {
                Toast.makeText(requireContext(), "Please enter a due date and time", Toast.LENGTH_SHORT).show();
                return;
            }

            if (validateDueDateAndTime(dueDate.getText().toString(),dueTime.getText().toString()) == false && reminderCheckBox.isChecked()) {
                Toast.makeText(requireContext(), "Please enter a valid due date and time", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean added = dataBaseHelper.insertTASK(task);
            if (added) {
                if (reminderCheckBox.isChecked() ) {

                    if (!task.getSTATUS().equals("incomplete")) {
                        Toast.makeText(requireContext(), "This Task is Already Completed ", Toast.LENGTH_SHORT).show();
                        return;
                    }


                    // Calculate trigger time, 30% before the task's due time
                    long triggerTime = getTriggerTime(dueDate.getText().toString(), dueTime.getText().toString());
                    if (triggerTime > System.currentTimeMillis()) {
                        // Schedule the reminder

                        //int requestCode = (task.getTITLE()).hashCode();
                        int requestCode = dataBaseHelper.getTaskIdByTitle(task.getTITLE(),useremail);
                        scheduleNotification(triggerTime, title.getText().toString(), requestCode);


                        // Display confirmation to the user
                        Date triggerDate = new Date(triggerTime);
                        Toast.makeText(requireContext(), "Task Added Successfully", Toast.LENGTH_SHORT).show();
                        Toast.makeText(requireContext(), "A reminder is scheduled at: " + triggerDate, Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(requireContext(), "The reminder time has already passed!", Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(requireContext(), "Task Added Successfully", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(requireContext(), "Task Already Exists, try another title", Toast.LENGTH_SHORT).show();
            }

        });

        // Edit Task button functionality
        Button editTaskButton = view.findViewById(R.id.edit_task_button);
        editTaskButton.setOnClickListener(v -> {
            TASK task = new TASK();
            task.setUSEREmail(useremail);
            task.setTITLE(title.getText().toString());
            task.setDESCRIPTION(description.getText().toString());
            task.setPRIORITY(prioritySpinner.getSelectedItem().toString());
            task.setSTATUS(statusSpinner.getSelectedItem().toString());
            task.setREMINDER(reminderCheckBox.isChecked() ? "yes" : "no");
            task.setDUEDATE(dueDate.getText().toString());
            task.setDUETIME(dueTime.getText().toString());

            boolean updated = dataBaseHelper.updateTASK(task , useremail) ;
            if (updated) {
                Toast.makeText(requireContext(), "Task Updated Successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(requireContext(), "Task Not Found", Toast.LENGTH_SHORT).show();
            }
        });

        // Delete Task button functionality
        Button deletetaskButton = view.findViewById(R.id.delete_task_button);
        deletetaskButton.setOnClickListener(v -> {
            boolean deleted = dataBaseHelper.deleteTASKbyUSER(title.getText().toString(),useremail);
            if (deleted) {
                Toast.makeText(requireContext(), "Task Deleted Successfully", Toast.LENGTH_SHORT).show();
                title.setText("");
                description.setText("");
                prioritySpinner.setSelection(0);
                statusSpinner.setSelection(0);
                dueDate.setText("");
                dueTime.setText("");
            } else {
                Toast.makeText(requireContext(), "Task Not Found", Toast.LENGTH_SHORT).show();
            }
        });

        // Search task functionality
        Button searchtaskButton = view.findViewById(R.id.buttonSearch);
        searchtaskButton.setOnClickListener(v -> {
            TASK task = dataBaseHelper.getTASK(title.getText().toString(),useremail);
            if (task != null) {
                title.setText(task.getTITLE());
                description.setText(task.getDESCRIPTION());
                prioritySpinner.setSelection(priorityAdapter.getPosition(task.getPRIORITY()));
                statusSpinner.setSelection(statusAdapter.getPosition(task.getSTATUS()));
                dueDate.setText(task.getDUEDATE());
                dueTime.setText(task.getDUETIME());
            } else {
                Toast.makeText(requireContext(), "Task Not Found", Toast.LENGTH_SHORT).show();
                title.setText("");
                description.setText("");
                prioritySpinner.setSelection(0);
                statusSpinner.setSelection(0);
                dueDate.setText("");
                dueTime.setText("");
            }
        });

        // Search task functionality
        Button shareTask = view.findViewById(R.id.shareTask);
        shareTask.setOnClickListener(v -> {
            if(title.getText().toString().isEmpty()){
                Toast.makeText(requireContext(), "Please enter a task title", Toast.LENGTH_SHORT).show();
                return;
            }
            Bundle bundle = new Bundle();
            bundle.putString("task_title", title.getText().toString()); // Add the task title to the bundle
            ShareFragment ShareFragment = new ShareFragment();
            ShareFragment.setArguments(bundle);  // Pass the bundle to the fragment
            requireFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, ShareFragment)
                    .addToBackStack(null)  //  add to back stack
                    .commit();

        });

        // Task description editing
        description.setOnClickListener(v -> {

            description.setFocusableInTouchMode(true);
            description.setFocusable(true);
            description.requestFocus();
        });



        return view;


    }

  private boolean validateDueDateAndTime(String dueDate, String dueTime) {
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
    try {
        Date date = dateFormat.parse(dueDate + " " + dueTime);
        if (date != null && date.before(new Date())) {
            return false; // The due date and time is before the current date and time
        }
    } catch (ParseException e) {
        e.printStackTrace();
        return false; // Invalid date format
    }
    return true; // The due date and time is valid and not before the current date and time
}

    private long getTriggerTime(String dueDate, String dueTime) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
        try {
            Date date = dateFormat.parse(dueDate + " " + dueTime);
            if (date != null) {
                return date.getTime() - (long) (0.3 * (date.getTime() - System.currentTimeMillis())); // Subtract 30% of the remaining time            }
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return System.currentTimeMillis(); // Default to current time if parsing fails
    }

    private void scheduleNotification(long triggerTime, String taskTitle, int requestCode) {
        Context context = requireContext();
        Intent intent = new Intent(context, ReminderBroadcastReceiver.class);
        intent.putExtra("taskTitle", taskTitle);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                requestCode, // Unique request code
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null) {
            alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerTime,
                    pendingIntent
            );
        }

        Toast.makeText(context, "Reminder scheduled for: " + new Date(triggerTime), Toast.LENGTH_LONG).show();
    }





}
