package com.example.project;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ImportTasksFragment extends Fragment {
    private DatabaseHelper databaseHelper;

    private TextView tvTasks;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_import_tasks, container, false);

        // Initialize DatabaseHelper
        databaseHelper = new DatabaseHelper(requireContext(), "TaskManagementAPP", null, 1);

        Button btnImportTasks = view.findViewById(R.id.btn_import_tasks);
        tvTasks = view.findViewById(R.id.tv_tasks);

        btnImportTasks.setOnClickListener(v -> importTasks());

        return view;
    }

    private void importTasks() {
        String apiUrl = "https://mocki.io/v1/4366220f-4e53-426a-9519-6c1a57e4afb2";
        new FetchTasksTask().execute(apiUrl);
    }

    private class FetchTasksTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {
            StringBuilder result = new StringBuilder();
            try {
                URL url = new URL(urls[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(connection.getInputStream())
                );
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }
                reader.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result.toString();
        }

        @Override
        protected void onPostExecute(String response) {
            SharedPreferences sharedPreferences;
            sharedPreferences = requireContext().getSharedPreferences("UserPrefs", requireContext().MODE_PRIVATE);
            String useremail= sharedPreferences.getString("email", "");

            try {
                JSONArray tasksArray = new JSONArray(response);
                StringBuilder displayText = new StringBuilder();

                for (int i = 0; i < tasksArray.length(); i++) {
                    JSONObject taskJson = tasksArray.getJSONObject(i);

                    TASK task = new TASK();
                    task.setUSEREmail(useremail);
                    task.setTITLE(taskJson.optString("title", "N/A"));
                    task.setDESCRIPTION(taskJson.optString("DESCRIPTION", "N/A"));
                    task.setPRIORITY(taskJson.optString("PRIORITY", "N/A"));
                    task.setSTATUS(taskJson.optString("STATUS", "N/A"));
                    task.setREMINDER(taskJson.optString("REMINDER", "N/A"));
                    task.setDUEDATE(taskJson.optString("DUEDATE", "N/A"));
                    task.setDUETIME(taskJson.optString("DUETIME", "N/A"));

                    // Use the existing insertTASK method
                    boolean added = databaseHelper.insertTASK(task);

                    if (added) {
                        displayText.append("Task added to database: \n")
                                .append(task.toString())
                                .append("\n\n");
                    } else {
                        displayText.append("*********\n")
                                .append(task.toString())
                                .append("\n\n");
                    }
                }

                tvTasks.setText(displayText.toString());
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(getActivity(), "Error loading tasks", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
