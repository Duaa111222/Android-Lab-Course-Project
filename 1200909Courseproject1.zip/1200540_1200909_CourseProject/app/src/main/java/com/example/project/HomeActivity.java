package com.example.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

public class HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;
    public androidx.appcompat.widget.SearchView searchView;
    SharedPreferences sharedPreferences;
    DatabaseHelper mydb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        mydb = new DatabaseHelper(this, "TaskManagementAPP", null, 1);
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);

        Toolbar toolbar = findViewById(R.id.toolbar); //Ignore red line errors
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(""); // to remove the title from the toolbar("Navigation Drawer")

        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_nav,
                R.string.close_nav);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
            navigationView.setCheckedItem(R.id.nav_home);
        }
        searchView = findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new androidx.appcompat.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // Create a new instance of filterFragment
                filterFragment fragment = new filterFragment();

                // Create a bundle to pass data
                Bundle args = new Bundle();
                args.putString("search_query", query); // Key-value pair for passing the query
                fragment.setArguments(args); // Set the bundle as arguments to the fragment

                // Begin transaction to replace the fragment
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, fragment)
                        .commit();

                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (newText.isEmpty()) {
                    // If the search is cleared, return to the previous fragment
                    if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
                        // Pop the current fragment and return to the previous one
                        getSupportFragmentManager().popBackStack();
                    }
                }
                return false; // Optional: Handle dynamic text change
            }
        });

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        Intent intent = getIntent();
        String email = intent.getStringExtra("userEMAIL");

        if (itemId == R.id.nav_home) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new HomeFragment())
                    .commit();
        } else if (itemId == R.id.nav_account) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new AccountFragment())
                    .commit();
        } else if (itemId == R.id.nav_reminder) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new ReminderFragment())
                    .commit();
        } else if (itemId == R.id.nav_addTask) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new ManageTasksFragment())
                    .commit();
        }else if (itemId == R.id.nav_mode) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new ChangeModeFragment())
                    .commit();
        }else if (itemId == R.id.nav_display) {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, new DisplayTasks())
                        .commit();

        }else if (itemId == R.id.nav_import) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new ImportTasksFragment())
                    .commit();

        }else if (itemId == R.id.nav_logout) {
            startActivity(new Intent(HomeActivity.this, MainActivity.class));

            Toast.makeText(this, "Logout!", Toast.LENGTH_SHORT).show();
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    public void performSearch(String query) {
        // Query the database
        SQLiteDatabase database = mydb.getReadableDatabase();
        Cursor cursor = database.rawQuery(
                "SELECT TITLE FROM TASKS WHERE TITLE LIKE ? OR DESCRIPTION LIKE ?",
                new String[]{"%" + query + "%", "%" + query + "%"}
        );

        if (cursor != null && cursor.moveToFirst()) {
            StringBuilder matchedTitles = new StringBuilder();
            do {
                matchedTitles.append(cursor.getString(cursor.getColumnIndexOrThrow("TITLE"))).append("\n");
            } while (cursor.moveToNext());
            cursor.close();

            // Pass matched titles as an argument to the fragment
            Bundle bundle = new Bundle();
            bundle.putString("matchedTitles", matchedTitles.toString());

            // Create the fragment and set the arguments
            DynamicFragment dynamicFragment = new DynamicFragment();
            dynamicFragment.setArguments(bundle);

            // Attempt to replace the current fragment
            try {
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.fragment_container, dynamicFragment);
                transaction.addToBackStack(null); // Optional: Allow user to go back to previous fragment
                transaction.commit();
            } catch (Exception e) {
                e.printStackTrace(); // Print any error in the Log
                Toast.makeText(this, "Error replacing fragment: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "No tasks found!", Toast.LENGTH_SHORT).show();
        }
    }

    // Define the fragment as a static class
    public static class DynamicFragment extends Fragment {

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            // Create a LinearLayout to hold the TextView dynamically
            LinearLayout layout = new LinearLayout(getActivity());
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16); // Padding for the layout

            // Get the matched titles from the arguments
            String matchedTitles = getArguments() != null ? getArguments().getString("matchedTitles") : "";

                //***********************
            // Create a TextView to display matched task titles
            TextView matchedTitlesTextView = new TextView(getActivity());
            matchedTitlesTextView.setText(matchedTitles);
            matchedTitlesTextView.setTextSize(16); // Set text size

            // Add the TextView to the layout
            layout.addView(matchedTitlesTextView);


            ///**************************
            // Return the layout
            return layout;
        }
    }



}