package com.example.project;

public class TASK {
    private String USEREmail;
    private String TITLE;
    private String DESCRIPTION;
    private String PRIORITY;
    private String STATUS;
    private String REMINDER;
    private String DUEDATE;
    private String DUETIME;
    private boolean isChecked;

    public TASK() {
    }

    public TASK(String USEREmail, String TITLE, String DESCRIPTION, String PRIORITY, String STATUS, String REMINDER, String DUEDATE, String DUETIME) {
        this.USEREmail = USEREmail;
        this.TITLE = TITLE;
        this.DESCRIPTION = DESCRIPTION;
        this.PRIORITY = PRIORITY;
        this.STATUS = STATUS;
        this.REMINDER = REMINDER;
        this.DUEDATE = DUEDATE;
        this.DUETIME = DUETIME;
        this.isChecked = false;
    }

    public String getUSEREmail() {
        return USEREmail;
    }

    public void setUSEREmail(String USEREmail) {
        this.USEREmail = USEREmail;
    }

    public String getTITLE() {
        return TITLE;
    }

    public void setTITLE(String TITLE) {
        this.TITLE = TITLE;
    }

    public String getDESCRIPTION() {
        return DESCRIPTION;
    }

    public void setDESCRIPTION(String DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }

    public String getPRIORITY() {
        return PRIORITY;
    }

    public void setPRIORITY(String PRIORITY) {
        this.PRIORITY = PRIORITY;
    }

    public String getSTATUS() {
        return STATUS;
    }

    public void setSTATUS(String STATUS) {
        this.STATUS = STATUS;
    }

    public String getREMINDER() {
        return REMINDER;
    }

    public void setREMINDER(String REMINDER) {
        this.REMINDER = REMINDER;
    }

    public String getDUEDATE() {
        return DUEDATE;
    }

    public void setDUEDATE(String DUEDATE) {
        this.DUEDATE = DUEDATE;
    }

    public String getDUETIME() {
        return DUETIME;
    }


    public void setDUETIME(String DUETIME) {
        this.DUETIME = DUETIME;
    }

    public boolean isChecked() {
        return isChecked;
    }

    public void setChecked(boolean checked) {
        isChecked = checked;
    }
    @Override
    public String toString() {
        return "TASK{" +
                "\n, USEREmail=" + USEREmail +
                "\n, TITLE='" + TITLE + '\'' +
                "\n, DESCRIPTION='" + DESCRIPTION + '\'' +
                "\n, PRIORITY='" + PRIORITY + '\'' +
                "\n, STATUS='" + STATUS + '\'' +
                "\n, REMINDER='" + REMINDER + '\'' +
                "\n, DUEDATE='" + DUEDATE + '\'' +
                "\n, DUETIME='" + DUETIME + '\'' +
                "\n}\n\n";
    }



}
