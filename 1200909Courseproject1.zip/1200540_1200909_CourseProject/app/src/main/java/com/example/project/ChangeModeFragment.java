package com.example.project;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Switch;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.appcompat.app.AppCompatDelegate;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class ChangeModeFragment extends Fragment {

    private Switch themeSwitch;
    private TextView themeTextView;
    private SharedPreferences sharedPreferences;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_change_mode, container, false);

        // Initialize the views
        themeSwitch = view.findViewById(R.id.themeSwitch);
        themeTextView = view.findViewById(R.id.themeTextView);

        // Initialize SharedPreferences to store user preference for theme
        sharedPreferences = getActivity().getSharedPreferences("UserPrefs", getActivity().MODE_PRIVATE);

        // Get the current theme preference from SharedPreferences
        boolean isDarkMode = sharedPreferences.getBoolean("isDarkMode", false);

        // Set the initial theme based on saved preference
        if (isDarkMode) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            themeTextView.setText("Current Mode: Dark");
            themeSwitch.setChecked(true);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            themeTextView.setText("Current Mode: Light");
            themeSwitch.setChecked(false);
        }

        // Set up listener for the switch to toggle themes
        themeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // Toggle between dark and light mode
            if (isChecked) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                themeTextView.setText("Current Mode: Dark");
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                themeTextView.setText("Current Mode: Light");
            }

            // Save the theme preference to SharedPreferences
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("isDarkMode", isChecked);
            editor.apply();
        });

        return view;
    }
}
