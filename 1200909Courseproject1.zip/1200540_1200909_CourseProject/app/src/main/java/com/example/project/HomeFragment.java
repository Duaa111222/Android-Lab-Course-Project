package com.example.project;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment implements TaskAdapter.OnTaskClickListener, TaskAdapter.OnTaskCheckChangeListener {

    RecyclerView recyclerView;
    FloatingActionButton addButton;
    TaskAdapter taskAdapter;
    DatabaseHelper myDB;
    String useremail;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerView = view.findViewById(R.id.recyclerview);
        addButton = view.findViewById(R.id.addButton);
        myDB = new DatabaseHelper(requireContext(), "TaskManagementAPP", null, 1);

        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        loadTasks(); // Load tasks from the database

        setUpItemTouchHelper(); // Set up swipe actions
        addButton.setOnClickListener(v -> {
            requireFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new ManageTasksFragment())
                    .commit();
        });

        return view;
    }

    @Override
    public void onTaskClick(TASK task) {
        // Create a Bundle and add the task title
        Bundle bundle = new Bundle();
        bundle.putString("task_title", task.getTITLE()); // Add the task title to the bundle
        ManageTasksFragment manageTasksFragment = new ManageTasksFragment();
        manageTasksFragment.setArguments(bundle);  // Pass the bundle to the fragment
        requireFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, manageTasksFragment)
                .addToBackStack(null)  //  add to back stack
                .commit();
    }


    private void loadTasks() {
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("UserPrefs", requireContext().MODE_PRIVATE);
        useremail = sharedPreferences.getString("email", "");
        ////for a day ordered by priority
        Cursor cursor = myDB.getUserTasksByEmailandduedate(useremail);
        List<TASK> tasks = new ArrayList<>();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") TASK task = new TASK(                        cursor.getString(cursor.getColumnIndex("userEMAIL")),
                        cursor.getString(cursor.getColumnIndex("TITLE")),
                        cursor.getString(cursor.getColumnIndex("DESCRIPTION")),
                        cursor.getString(cursor.getColumnIndex("PRIORITY")),
                        cursor.getString(cursor.getColumnIndex("STATUS")),
                        cursor.getString(cursor.getColumnIndex("REMINDER")),
                        cursor.getString(cursor.getColumnIndex("DUEDATE")),
                        cursor.getString(cursor.getColumnIndex("DUETIME"))
                );
                tasks.add(task);
            } while (cursor.moveToNext());
        }

        if (cursor != null) {
            cursor.close();
        }

        taskAdapter = new TaskAdapter(requireContext(),tasks, this, myDB, this);
        recyclerView.setAdapter(taskAdapter);
    }


    @Override
    public void onTaskChecked(boolean isChecked) {
        // Handle individual checkbox change
        if (isChecked) {
            Toast.makeText(getContext(), "A task is checked!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getContext(), "A task is unchecked!", Toast.LENGTH_SHORT).show();
        }
    }

    @Override


    public void onAllTasksChecked() {
        // Inflate custom dialog layout
        View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.congratulations_dialog, null);

        // Initialize animation
        Animation animation = AnimationUtils.loadAnimation(requireContext(), R.anim.congratulations_animation);
        ImageView imageView = dialogView.findViewById(R.id.congratulationsImage);
        imageView.startAnimation(animation);

        // Create and show dialog
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(requireContext());
        builder.setView(dialogView)
                .setCancelable(false)
                .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                .show();
    }


    private void setUpItemTouchHelper() {
        ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false; // No need to handle item movement
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                TASK swipedTask = taskAdapter.getTaskAt(position); // Get the task at this position

                if (direction == ItemTouchHelper.LEFT) {
                    // Swipe left - display a toast (or perform any other action like marking as complete)
                    Toast.makeText(requireContext(), "Share Task via Email: " + swipedTask.getTITLE(), Toast.LENGTH_SHORT).show();

                    Bundle bundle = new Bundle();
                    bundle.putString("task_title", swipedTask.getTITLE()); // Add the task title to the bundle
                    ShareFragment ShareFragment = new ShareFragment();
                    ShareFragment.setArguments(bundle);  // Pass the bundle to the fragment
                    requireFragmentManager().beginTransaction()
                            .replace(R.id.fragment_container, ShareFragment)
                            .addToBackStack(null)  //  add to back stack
                            .commit();

                } else if (direction == ItemTouchHelper.RIGHT) {
                    // Swipe right - delete the task
                    Toast.makeText(requireContext(), "Task deleted: " + swipedTask.getTITLE(), Toast.LENGTH_SHORT).show();
                    myDB.deleteTASKbyUSER(swipedTask.getTITLE(),useremail);  // Assuming you have a method for deleting tasks by title

                    // Remove the task from the list and update the adapter
                    taskAdapter.removeTask(position);
                }
            }
        };

        // Attach the ItemTouchHelper to the RecyclerView
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (myDB != null) {
            myDB.close();
        }
    }

}

