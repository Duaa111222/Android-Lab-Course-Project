package com.example.project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

public class DatabaseHelper extends android.database.sqlite.SQLiteOpenHelper {

    public DatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE USERS(ID INTEGER PRIMARY KEY AUTOINCREMENT,EMAIL TEXT UNIQUE NOT NULL,PASSWORD TEXT NOT NULL, FIRSTNAME TEXT NOT NULL,LASTNAME TEXT NOT NULL)");
        sqLiteDatabase.execSQL("CREATE TABLE TASKS(ID INTEGER PRIMARY KEY AUTOINCREMENT, userEMAIL TEXT NOT NULL,TITLE TEXT NOT NULL,DESCRIPTION TEXT NOT NULL,PRIORITY TEXT NOT NULL,STATUS TEXT NOT NULL,REMINDER TEXT NOT NULL, DUEDATE TEXT NOT NULL,DUETIME TEXT NOT NULL)");
        sqLiteDatabase.execSQL("PRAGMA foreign_keys = ON;");


    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    //*
    public Boolean insertTASK(TASK task) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        // Check if a task with the same title exists for the user
        Cursor cursor = sqLiteDatabase.rawQuery(
                "SELECT COUNT(*) FROM TASKS WHERE userEMAIL = ? AND TITLE = ?",
                new String[]{task.getUSEREmail(), task.getTITLE()}
        );

        if (cursor != null) {
            cursor.moveToFirst();
            int count = cursor.getInt(0);
            cursor.close();

            if (count > 0) {
                // Task already exists for this user
                System.out.println("Task with the same title already exists for the user.");
                sqLiteDatabase.close();
                return false; // Do not insert the task
            }
        }

        ContentValues values = new ContentValues();
        values.put("userEMAIL", task.getUSEREmail());
        values.put("TITLE", task.getTITLE());
        values.put("DESCRIPTION", task.getDESCRIPTION());
        values.put("PRIORITY", task.getPRIORITY());
        values.put("STATUS", task.getSTATUS());
        values.put("REMINDER", task.getREMINDER());
        values.put("DUEDATE", task.getDUEDATE());
        values.put("DUETIME", task.getDUETIME());

        sqLiteDatabase.insert("TASKS", null, values);
        sqLiteDatabase.close();
        return true;
    }



    public boolean  insertUSER(USER user) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("EMAIL", user.getEmail());
        contentValues.put("PASSWORD", user.getPassword());
        contentValues.put("FIRSTNAME", user.getFIRSTName());
        contentValues.put("LASTNAME", user.getLASTName());


        //check the uniqueness of The EMAIL
        try {
            sqLiteDatabase.insertOrThrow("USERS", null, contentValues);
            return true;  // If successful, return true
        } catch (SQLiteConstraintException e) {
            return false;
        } finally {
            sqLiteDatabase.close();
        }
    }
//*******************************************************************************


    //get task id by title for a specific user
    public int getTaskIdByTitle(String title, String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT ID FROM TASKS WHERE TITLE = ? AND userEMAIL = ?", new String[]{title, email});
        if (cursor != null && cursor.moveToFirst()) {
            int id = cursor.getInt(0);
            cursor.close();
            db.close();
            return id;
        } else {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
            return -1; // Return -1 if no task is found
        }
    }

    public Cursor getAllusers() {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        return sqLiteDatabase.rawQuery("SELECT * FROM USERS", null);
    }
    public Cursor getAlltasks() {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        return sqLiteDatabase.rawQuery("SELECT * FROM TASKS", null);
    }
    public Cursor getuser(String email,String password) {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        return sqLiteDatabase.rawQuery("SELECT * FROM USERS WHERE EMAIL = ? AND PASSWORD = ?", new String[]{email, password});
    }
    public USER getuserbyemail(String email) {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM USERS WHERE EMAIL = ?", new String[]{email});

        if (cursor != null && cursor.moveToFirst()) {
            USER user = new USER();
            user.setEmail(cursor.getString(1));
            user.setPassword(cursor.getString(2));
            user.setFIRSTName(cursor.getString(3));
            user.setLASTName(cursor.getString(4));

            cursor.close();
            sqLiteDatabase.close();
            return user;
        } else {
            if (cursor != null) {
                cursor.close();
            }
            sqLiteDatabase.close();
            return null; // Return null if no user is found
        }
    }

    //ordered by priority
    public Cursor getUserTasksByEmailandduedate(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        // Retrieve tasks where the due date is close to the current date and order by priority
        return db.rawQuery("SELECT * FROM TASKS " +
                        "WHERE userEMAIL = ? " +
                        "AND DUEDATE BETWEEN date('now') AND date('now', '1 day') " +
                        "ORDER BY " +
                        "CASE " +
                        "WHEN PRIORITY = 'High' THEN 1 " +
                        "WHEN PRIORITY = 'Medium' THEN 2 " +
                        "WHEN PRIORITY = 'Low' THEN 3 " +
                        "ELSE 4 END, " +
                        "DUEDATE ASC",
                new String[]{email});
    }

    // write deleteTASK related to a user
    public boolean deleteTASKbyUSER(String title , String email) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        int deleted = sqLiteDatabase.delete("TASKS", "TITLE = ? AND userEMAIL = ?", new String[]{title, email});
        sqLiteDatabase.close();
        return deleted > 0;
    }

    //select  displays all the to-do tasks sorted chronologically and grouped by day.
    public Cursor selectAllTasks_grouped_by_day(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM TASKS WHERE userEMAIL = ? ORDER BY DUEDATE ASC", new String[]{email});
    }
    //displays all completed tasks sorted chronologically and grouped by day
    public Cursor selectCompletedTasks_grouped_by_day(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM TASKS WHERE userEMAIL = ? AND STATUS = 'Complete' ORDER BY DUEDATE ASC", new String[]{email});
    }

    //: allows the user to display to-do tasks in a period specified by a start date and and end date.
    public Cursor Tasksinspecificdate_grouped_by_day(String email,String startDate, String endDate) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM TASKS WHERE userEMAIL = ? AND DUEDATE BETWEEN ? AND ? ORDER BY DUEDATE ASC", new String[]{email, startDate, endDate});
    }
    public boolean updateTaskStatus(String title,String email, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("STATUS", status);
        int rowsAffected = db.update("TASKS", values, "TITLE = ? AND userEMAIL = ?", new String[]{title,email});
        db.close();
        return rowsAffected > 0;
    }


    public TASK getTASK(String title, String email) {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM TASKS WHERE TITLE = ? AND userEMAIL=?", new String[]{title ,email });

        if (cursor != null && cursor.moveToFirst()) {
            TASK task = new TASK();
            task.setUSEREmail(cursor.getString(1));
            task.setTITLE(cursor.getString(2));
            task.setDESCRIPTION(cursor.getString(3));
            task.setPRIORITY(cursor.getString(4));
            task.setSTATUS(cursor.getString(5));
            task.setREMINDER(cursor.getString(6));
            task.setDUEDATE(cursor.getString(7));
            task.setDUETIME(cursor.getString(8));

            cursor.close();
            sqLiteDatabase.close();
            return task;
        } else {
            if (cursor != null) {
                cursor.close();
            }
            sqLiteDatabase.close();
            return null; // Return null if no task is found
        }
    }


    //write updateTASK
    public boolean updateTASK(TASK task , String email) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("userEMAIL", task.getUSEREmail());
        values.put("TITLE", task.getTITLE());
        values.put("DESCRIPTION", task.getDESCRIPTION());
        values.put("PRIORITY", task.getPRIORITY());
        values.put("STATUS", task.getSTATUS());
        values.put("REMINDER", task.getREMINDER());
        values.put("DUEDATE", task.getDUEDATE());
        values.put("DUETIME", task.getDUETIME());

        int updated = sqLiteDatabase.update("TASKS", values, "TITLE = ? AND userEMAIL =?", new String[]{task.getTITLE(),email});
        sqLiteDatabase.close();
        return updated > 0;
    }
    public boolean updateUSER(USER user, String oldEmail) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("EMAIL", user.getEmail());
        values.put("PASSWORD", user.getPassword());
        values.put("FIRSTNAME", user.getFIRSTName());
        values.put("LASTNAME", user.getLASTName());
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT COUNT(*) FROM USERS WHERE EMAIL = ? AND EMAIL != ?", new String[]{user.getEmail(), oldEmail});
        cursor.moveToFirst();
        int count = cursor.getInt(0);
        cursor.close();

        if (count > 0) {
            // Email is not unique
            sqLiteDatabase.close();
            return false; // Do not update the user
        }

        int updated = sqLiteDatabase.update("USERS", values, "EMAIL = ?", new String[]{oldEmail});
        sqLiteDatabase.close();
        return updated > 0;
    }



//*******************************************************************************





}

