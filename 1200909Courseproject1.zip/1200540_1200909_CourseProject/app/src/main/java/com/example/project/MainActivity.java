package com.example.project;


import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText emailEditText, passwordEditText;
    CheckBox rememberMeCheckBox;
    Button signInButton, signUpButton;
    SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        rememberMeCheckBox = findViewById(R.id.rememberMeCheckBox);
        signInButton = findViewById(R.id.signInButton);
        signUpButton = findViewById(R.id.signUpButton);

        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        DatabaseHelper dataBaseHelper = new DatabaseHelper(this, "TaskManagementAPP", null, 1);

        // Check if Remember Me is enabled
        if (sharedPreferences.getBoolean("rememberMe", false)) {
            emailEditText.setText(sharedPreferences.getString("email", ""));
            rememberMeCheckBox.setChecked(true);
        }

        signInButton.setOnClickListener(v -> {
            String email = emailEditText.getText().toString();
            String password = passwordEditText.getText().toString();

                sharedPreferences.edit()
                        .putString("email", email)
                        .putString("password", password)
                        .apply();


            // add the new user
            Cursor userexisit = dataBaseHelper.getuser(email, password);

            if (userexisit.getCount() > 0) {
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();

                if (rememberMeCheckBox.isChecked()) {
                    sharedPreferences.edit().putBoolean("rememberMe", true).apply();
                } else {
                    sharedPreferences.edit().putBoolean("rememberMe", false).apply();
                }

                Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                MainActivity.this.startActivity(intent);
            } else {
                Toast.makeText(this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
            }
        });

        signUpButton.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, SignupActivity.class)));
        //signUpButton.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, HomeActivity.class)));

    }
}
