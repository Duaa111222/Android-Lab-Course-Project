package com.example.project;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {

    EditText emailEditText, firstNameEditText, lastNameEditText, passwordEditText, confirmPasswordEditText;
    Button registerButton, returnButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Initialize UI components
        emailEditText = findViewById(R.id.emailEditText);
        firstNameEditText = findViewById(R.id.firstNameEditText);
        lastNameEditText = findViewById(R.id.lastNameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        confirmPasswordEditText = findViewById(R.id.confirmPasswordEditText);
        registerButton = findViewById(R.id.registerButton);
        returnButton = findViewById(R.id.returnButton);

        // Initialize database helper
        DatabaseHelper databaseHelper = new DatabaseHelper(this, "TaskManagementAPP", null, 1);

        // Set up register button listener
        registerButton.setOnClickListener(v -> {
            String email = emailEditText.getText().toString().trim();
            String firstName = firstNameEditText.getText().toString().trim();
            String lastName = lastNameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();
            String confirmPassword = confirmPasswordEditText.getText().toString().trim();

            // Validate inputs
            if (validateInput(email, firstName, lastName, password, confirmPassword)) {
                USER newUser = new USER();
                newUser.setFIRSTName(firstName);
                newUser.setLASTName(lastName);
                newUser.setEmail(email);
                newUser.setPassword(password);

                // Add the new user to the database
                boolean added = databaseHelper.insertUSER(newUser);
                if (added) {
                    Toast.makeText(this, "User Registered Successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(SignupActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(this, "Email already exists. Choose another one", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set up return button listener
        returnButton.setOnClickListener(v -> {
            Intent intent = new Intent(SignupActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private boolean validateInput(String email, String firstName, String lastName, String password, String confirmPassword) {
        if (TextUtils.isEmpty(email) || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailEditText.setError("Enter a valid email");
            return false;
        }
        if (firstName.length() < 5 || firstName.length() > 20) {
            firstNameEditText.setError("First name must be 5-20 characters");
            return false;
        }
        if (lastName.length() < 5 || lastName.length() > 20) {
            lastNameEditText.setError("Last name must be 5-20 characters");
            return false;
        }
        if (!password.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{6,12}$")) {
            passwordEditText.setError("Password must be 6-12 characters with a number, a lowercase, and an uppercase letter");
            return false;
        }
        if (!password.equals(confirmPassword)) {
            confirmPasswordEditText.setError("Passwords do not match");
            return false;
        }
        return true;
    }
}
